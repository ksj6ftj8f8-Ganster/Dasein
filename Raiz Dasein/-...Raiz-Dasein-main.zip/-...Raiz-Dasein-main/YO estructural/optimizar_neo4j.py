#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script para optimizar la base de datos Neo4j
Crea índices y constraints necesarios para mejorar el rendimiento
"""

import yaml
from database import Neo4jConnection
from neo4j.exceptions import ClientError

def crear_base_datos(uri, username, password, database_name):
    """Crea la base de datos si no existe (conectándose a la BD system)"""
    
    print(f"\n🔨 Verificando base de datos '{database_name}'...")
    
    try:
        # Conectar a la base de datos 'system' para crear la BD
        system_connection = Neo4jConnection(
            uri, username, password,
            database='system',  # Conectar a system para crear BDs
            timeout=30
        )
        
        # Verificar si la base de datos existe
        query_verificar = "SHOW DATABASES"
        databases = system_connection.query(query_verificar)
        
        db_existe = False
        for db in databases:
            if db.get('name') == database_name:
                db_existe = True
                print(f"   ✅ La base de datos '{database_name}' ya existe")
                break
        
        # Crear la base de datos si no existe
        if not db_existe:
            print(f"   ⚠️  La base de datos '{database_name}' no existe. Creándola...")
            query_crear = f"CREATE DATABASE `{database_name}` IF NOT EXISTS"
            system_connection.query(query_crear)
            print(f"   ✅ Base de datos '{database_name}' creada exitosamente")
        
        system_connection.close()
        return True
        
    except Exception as e:
        print(f"   ⚠️  No se pudo verificar/crear la BD: {str(e)}")
        print(f"   ℹ️  Esto es normal si tu usuario no tiene permisos de administrador")
        print(f"   ℹ️  Asegúrate de que la BD '{database_name}' exista manualmente")
        return False

def crear_indices_y_constraints(db_connection):
    """Crea todos los índices y constraints necesarios para optimizar Neo4j"""
    
    print("🔧 Optimizando base de datos Neo4j...")
    print("=" * 60)
    
    # Lista de comandos para crear índices y constraints
    comandos = [
        # Constraint único para nodos YO
        ("CREATE CONSTRAINT yo_id_unique IF NOT EXISTS FOR (y:YO) REQUIRE y.id IS UNIQUE", 
         "Constraint único para YO.id"),
        
        # Constraint único para nodos Contexto
        ("CREATE CONSTRAINT contexto_id_unique IF NOT EXISTS FOR (c:Contexto) REQUIRE c.id IS UNIQUE",
         "Constraint único para Contexto.id"),
        
        # Constraint único para nodos Reflexion
        ("CREATE CONSTRAINT reflexion_id_unique IF NOT EXISTS FOR (r:Reflexion) REQUIRE r.id IS UNIQUE",
         "Constraint único para Reflexion.id"),
        
        # Constraint único para nodos Contradiccion
        ("CREATE CONSTRAINT contradiccion_id_unique IF NOT EXISTS FOR (cont:Contradiccion) REQUIRE cont.id IS UNIQUE",
         "Constraint único para Contradiccion.id"),
        
        # Índices adicionales para mejorar búsquedas
        ("CREATE INDEX yo_tipo_idx IF NOT EXISTS FOR (y:YO) ON (y.tipo)",
         "Índice para YO.tipo"),
        
        ("CREATE INDEX yo_timestamp_idx IF NOT EXISTS FOR (y:YO) ON (y.timestamp)",
         "Índice para YO.timestamp"),
        
        ("CREATE INDEX reflexion_timestamp_idx IF NOT EXISTS FOR (r:Reflexion) ON (r.timestamp)",
         "Índice para Reflexion.timestamp"),
    ]
    
    exitos = 0
    errores = 0
    
    for comando, descripcion in comandos:
        try:
            print(f"\n📌 Creando: {descripcion}")
            db_connection.query(comando)
            print(f"   ✅ Creado exitosamente")
            exitos += 1
        except Exception as e:
            if "already exists" in str(e).lower() or "equivalent" in str(e).lower():
                print(f"   ℹ️  Ya existe")
                exitos += 1
            else:
                print(f"   ❌ Error: {str(e)}")
                errores += 1
    
    print("\n" + "=" * 60)
    print(f"✅ Optimización completada:")
    print(f"   • Éxitos: {exitos}")
    print(f"   • Errores: {errores}")
    print("=" * 60)
    
    return exitos, errores

def verificar_indices(db_connection):
    """Verifica los índices y constraints existentes"""
    
    print("\n🔍 Verificando índices y constraints existentes...")
    print("=" * 60)
    
    try:
        # Listar constraints
        print("\n📋 Constraints:")
        constraints = db_connection.query("SHOW CONSTRAINTS")
        if constraints:
            for c in constraints:
                print(f"   • {c.get('name', 'N/A')}: {c.get('type', 'N/A')}")
        else:
            print("   ⚠️  No se encontraron constraints")
        
        # Listar índices
        print("\n📋 Índices:")
        indices = db_connection.query("SHOW INDEXES")
        if indices:
            for idx in indices:
                print(f"   • {idx.get('name', 'N/A')}: {idx.get('type', 'N/A')} - Estado: {idx.get('state', 'N/A')}")
        else:
            print("   ⚠️  No se encontraron índices")
            
    except Exception as e:
        print(f"   ❌ Error al verificar: {str(e)}")
    
    print("=" * 60)

def main():
    """Función principal"""
    
    print("\n🧠 OPTIMIZACIÓN DE BASE DE DATOS NEO4J")
    print("=" * 60)
    
    # Cargar configuración
    try:
        with open('configuracion/config.yaml', 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
    except FileNotFoundError:
        print("❌ Error: No se encontró el archivo de configuración")
        print("   Asegúrate de tener configuracion/config.yaml")
        return False
    
    # Conectar a Neo4j
    neo4j_config = config.get('neo4j', {})
    
    # Construir URI desde host y puerto
    host = neo4j_config.get('host', 'localhost')
    port = neo4j_config.get('port', 7687)
    uri = neo4j_config.get('uri', f'bolt://{host}:{port}')
    username = neo4j_config.get('username', 'neo4j')
    password = neo4j_config.get('password', 'password')
    database = neo4j_config.get('database', 'neo4j')
    
    # Paso 1: Intentar crear la base de datos si es posible
    db_created = crear_base_datos(uri, username, password, database)

    # Si no se pudo crear/verificar la BD, es posible que estemos en Community
    # (no soporta CREATE DATABASE). En ese caso haremos fallback a 'neo4j'.
    if not db_created and database != 'neo4j':
        print(f"\n⚠️  No se pudo crear/verificar la base '{database}'. Intentando usar la base 'neo4j' (Community Edition).")
        database = 'neo4j'

    # Intentar conectarse (primero con la base elegida, luego con fallback si es necesario)
    try:
        connection = Neo4jConnection(
            uri,
            username,
            password,
            database=database,
            timeout=neo4j_config.get('timeout', 30),
            max_retry=neo4j_config.get('max_retry', 3),
            pool_size=neo4j_config.get('pool_size', 50)
        )

    except Exception as e:
        # Si el error indica que la base no existe, volver a intentar con 'neo4j'
        err_str = str(e).lower()
        if ('database does not exist' in err_str or 'database not found' in err_str) and database != 'neo4j':
            print(f"\n⚠️  La base '{database}' no existe en el servidor. Reintentando con la base 'neo4j'...")
            try:
                connection = Neo4jConnection(
                    uri,
                    username,
                    password,
                    database='neo4j',
                    timeout=neo4j_config.get('timeout', 30),
                    max_retry=neo4j_config.get('max_retry', 3),
                    pool_size=neo4j_config.get('pool_size', 50)
                )
                database = 'neo4j'
            except Exception as e2:
                print(f"\n❌ Error crítico al conectar con 'neo4j': {str(e2)}")
                import traceback
                traceback.print_exc()
                return False
        else:
            print(f"\n❌ Error crítico: {str(e)}")
            import traceback
            traceback.print_exc()
            return False

    # Si llegamos aquí, la conexión fue exitosa
    try:
        print("✅ Conectado a Neo4j exitosamente\n")

        # Verificar índices existentes (antes)
        verificar_indices(connection)

        # Crear índices y constraints
        exitos, errores = crear_indices_y_constraints(connection)

        # Verificar índices existentes (después)
        verificar_indices(connection)

        # Cerrar conexión
        connection.close()

        print("\n✅ Optimización completada exitosamente")
        return errores == 0

    except Exception as e:
        print(f"\n❌ Error durante la optimización: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    import sys
    exito = main()
    sys.exit(0 if exito else 1)
